#!/opt/local/bin/python3.3
#kverdey1:ex_2_4.py:hw5,ex2,p4:python

#Ex.2.4.a
i1=input("Input number 1:")

#Ex.2.4.b
i2=input("Input number 2:")

#Ex.2.4.c
i3=i1+i2
print("The sum is:",i3)
