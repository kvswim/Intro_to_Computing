#!/opt/local/bin/python3.3
#kverdey1:ex_1_1.py:homework 5, excercise 1:python
"""this is
a multiple line
comment"""
variable="Hello World!"
print(variable)
