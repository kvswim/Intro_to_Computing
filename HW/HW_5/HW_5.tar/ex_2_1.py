#!/opt/local/bin/python3.3
#kverdey1:ex_1_2.py:homework 5, exercise 2
#Ex.2.1.a
v1=2+3
v2=2/3

#ex.2.1.b
type(v1)
#v1 is an int

#ex.2.1.c
type(v2)
#v2 is a float

#ex.2.1.d
v3=float(v1)

#ex.2.1.e
v4=int(v2)

#ex.2.1.f
print(v1**2)

#ex.2.1.g
print("v1=",v1,"and v2","{0:.3f}".format(v2))
