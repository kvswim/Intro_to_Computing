#!/opt/local/bin/python3.3
#kverdey1:ex_1_2.py:homewodkrk 5, exercise 1:python
w_earth=150
g_earth=9.81
g_moon=1.62
g_jupiter=25.93
w_moon=(w_earth/g_earth)*g_moon
w_jupiter=(w_earth/g_earth)*g_jupiter
print("Weight on earth:",w_earth)
print("weight on the moon:",w_moon)
print("weight on Jupiter:",w_jupiter)


