#!/usr/bin/python3.4
# adamjan1:date:script full of errors

#comments usually only have one pound sign 
""" Please help me 
fix this scrtipt !!! """


print("some Python stuff")#quotes have to be the same, error is helpful 
#variable should only be one type, error is helpful
a=1
#b needs to be defined

b=2
print(a+b)
#power is only 2 stars
2**3
#print is misspelled 
print('will this work?')
#objects need to be of the same type, error is helpuful
1+2
