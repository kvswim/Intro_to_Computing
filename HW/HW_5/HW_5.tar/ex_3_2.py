#!/opt/local/bin/python3.3
#kverdey1:ex_3_2.py:ex3,p2:python

#Ex.3.2.a
mylist=[1,'420 braise it erry other day',[420,69,'rekt']]

#Ex.3.2.b
mytuple=tuple(mylist)

#Ex.3.2.c
type(mylist[0]) #int
type(mylist[1]) #str
type(mylist[2]) #list

#Ex.3.2.d
mylist[2][0]

#Ex.3.2.e
mystring1=str(mylist[0]*2)

#Ex.3.2.f
mylist2=['this','is','the','final','question','of','hw_5']
mystring2=' '.join(mylist2)

#Ex.3.2.g
mylist3=mystring2.split() 
