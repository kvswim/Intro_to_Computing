for file in "$HOME"/*; do
	echo $file
done
