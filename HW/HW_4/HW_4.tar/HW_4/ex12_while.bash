i=$((0))
while [ $i -lt 5 ]
do
	echo "I am number $i and I am smaller than 5"
	i=$((i+1))
done
