#!/opt/local/bin/python3.3
#kverdey1:ex_4_2.py:excercise 4, problem 2:python
#ex.4.2.a
def cuboid( x,y,z ):
	return x * y * z
#ex.4.2.b
my_cuboid=[2,3,4]
#ex.4.2.c
print("The volume of my cuboid is ",my_cuboid[0]*my_cuboid[1]*my_cuboid[2])
#ex.4.2.d
#uhh