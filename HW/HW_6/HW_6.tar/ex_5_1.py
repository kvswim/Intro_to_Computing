#!/opt/local/bin/python3.3
#kverdey1:ex_5_1.py:excercise 5, problem 1:python
#ex.5.1.a
import math
math.pow(9,12)
math.cos(0)
deg=90
rad=math.radians(x)
math.sin(math.radians(90))