#!/opt/local/bin/python3.3
#kverdey1:ex_5_3.py:excercise 5, problem 3:python
#ex.5.3.a
import shapes
circle=shapes.circle(5)
print("area: ",circle[1])
cube=shapes.cuboid(8,8,8)
print("the volume is: ",cube)