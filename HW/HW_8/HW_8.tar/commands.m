%disp('Hi!')
%sort([3 6 1 2])
%rand(4)
%randi([1,5],2,3)
%help disp
%save
%bar(1:5,[3,2,1,6,7])